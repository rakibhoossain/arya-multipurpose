<?php
/**
 * Register taxonomies
 *
 * @link       www.rakibhossain.cf
 * @since      1.0.0
 *
 * @package    Vcpm
 * @subpackage Vcpm/includes
 */
class Vcpm_Taxonomy {

    /**
     * Add taxonomies(portfolio category)
     *
     * @link https://codex.wordpress.org/Function_Reference/register_taxonomy
     */
    public function vcpm_taxonomy_program() {
        $labels = array(
            'name'              => _x( 'Program Categories', 'taxonomy general name', 'vcpm' ),
            'singular_name'     => _x( 'Program Category', 'taxonomy singular name', 'vcpm' ),
            'search_items'      => __( 'Search Program Categories', 'vcpm' ),
            'all_items'         => __( 'All Program Categories', 'vcpm' ),
            'parent_item'       => __( 'Parent Program Category', 'vcpm' ),
            'parent_item_colon' => __( 'Parent Program Category:', 'vcpm' ),
            'edit_item'         => __( 'Edit Program Category', 'vcpm' ), 
            'update_item'       => __( 'Update Program Category', 'vcpm' ),
            'add_new_item'      => __( 'Add New Program Category', 'vcpm' ),
            'new_item_name'     => __( 'New Program Category', 'vcpm' ),
            'menu_name'         => __( 'Program Categories', 'vcpm' ),
        );
        $args = array(
            'labels' => $labels,
            'hierarchical' => true,
        );
        register_taxonomy( 'rogram_category', 'program', apply_filters('vcpm_program_category_params', $args) );
    }
}
