<?php
/**
 * Register custom post types
 *
 * @link       www.rakibhossain.cf
 * @since      1.0.0
 *
 * @package    Vcpm
 * @subpackage Vcpm/includes
 */
class Vcpm_Post_Types {

    /**
     * Create post types
     *
     * @link https://codex.wordpress.org/Function_Reference/register_post_type
     */
    public function vcpm_program() {
        $vcpm_program_params = array(
            'labels' => array(
                'name' => __( 'Programs', 'violet-plugin' ),
                'singular_name' => __( 'Program' , 'violet-plugin'),
                'add_new' => __( 'Add New Program', 'violet-plugin' ),
                'add_new_item' => __( 'Add New Program', 'violet-plugin' ),
                'edit_item' => __( 'Edit Program', 'violet-plugin' ),
                'new_item' => __( 'Add New Program', 'violet-plugin' ),
                'view_item' => __( 'View Program', 'violet-plugin' ),
                'search_items' => __( 'Search Program', 'violet-plugin' ),
                'not_found' => __( 'No Program found', 'violet-plugin' ),
                'not_found_in_trash' => __( 'No Program found in trash', 'violet-plugin' )
            ),
            'menu_icon' => 'dashicons-format-audio',
            'public' => true,
            'show_in_rest' => true,
            'supports' => array( 'title', 'thumbnail', 'editor'),
            'capability_type' => 'post',
            'rewrite' => array(
                    "slug" => esc_attr__( 'program', 'vcpm' ) // Permalinks format
                ), 
            'has_archive' => true,
            // 'menu_position' => 5
        );
        register_post_type( 'program',
            apply_filters('vcpm_program_params', $vcpm_program_params)
        );
    }

    public function vcpm_rj() {
        $vcpm_rj_params = array(
            'labels' => array(
                'name' => __( 'RJ', 'vcpm' ),
                'singular_name' => __( 'RJ' , 'vcpm'),
                'add_new' => __( 'Add New RJ', 'vcpm' ),
                'add_new_item' => __( 'Add New RJ', 'vcpm' ),
                'edit_item' => __( 'Edit RJ', 'vcpm' ),
                'new_item' => __( 'Add New RJ', 'vcpm' ),
                'view_item' => __( 'View RJ', 'vcpm' ),
                'search_items' => __( 'Search RJ', 'vcpm' ),
                'not_found' => __( 'No RJ found', 'vcpm' ),
                'not_found_in_trash' => __( 'No RJ found in trash', 'vcpm' )
            ),
            'menu_icon' => 'dashicons-groups',
            'show_in_rest' => true,
            'supports' => array( 'title', 'thumbnail', 'editor'),
            'capability_type' => 'post',
            'rewrite' => array(
                    "slug" => esc_attr__( 'rj', 'vcpm' ) // Permalinks format
                ),
            'public' => true,
            'has_archive' => true
        );
        register_post_type( 'rj',
            apply_filters('vcpm_rj_params', $vcpm_rj_params)
        );
    }
}
